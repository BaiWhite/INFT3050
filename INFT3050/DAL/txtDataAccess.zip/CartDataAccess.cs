﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using INFT3050.Model;
using INFT3050.DAL;

namespace INFT3050.DAL
{
    /// <summary>
    /// using cart related table, which include not only Cart table but also CartItem table
    /// </summary>
    public class CartDataAccess
    {
        /// <summary>
        /// the path of the application
        /// </summary>
        String path = AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>
        /// read info in Cart.txt
        /// </summary>
        /// <returns>lines</returns>
        public List<Cart> ReadCartText()
        {
            string[] lines = System.IO.File.ReadAllLines(path + "DAL/Cart.txt");
            List<Cart> carts = new List<Cart>();
            Cart cart = new Cart();
            foreach (string line in lines)
            {
                string[] cartInfo = line.Split(',');
                cart.CartID = Convert.ToInt32(cartInfo[0]);
                cart.UserName = cartInfo[1];
                cart.Status = cartInfo[2];
            }
            return carts;
        }

        /// <summary>
        /// read info in CartItem.txt
        /// </summary>
        /// <returns>lines</returns>
        public Cart ReadCartItemText(Cart cart)
        {
            string[] lines = System.IO.File.ReadAllLines(path + @"DAL/CartItem.txt");
            CartItem cartItem = new CartItem();
            foreach (string line in lines)
            {
                string[] cartItemsInfo = line.Split(',');
                if (cart.CartID == Convert.ToInt32(cartItemsInfo[0]))
                {
                    cartItem.Amount = Convert.ToInt32(cartItemsInfo[1]);
                    cartItem.ProductID = Convert.ToInt32(cartItemsInfo[2]);
                    ProductDataAccess productDataAccess = new ProductDataAccess();
                    cartItem.ProductName = productDataAccess.GetProduct(cartItemsInfo[2]).Name;
                    cart.Items.Add(cartItem);
                }
            }
            return cart;
        }

        /// <summary>
        /// get list of cart based on keywards like cartId, status
        /// list items in cart if withItem = true, otherwise just return basic cart information
        /// </summary>
        /// <param name="cartId">cart ID</param>
        /// <param name="status">status</param>
        /// <param name="withItem">weather with item</param>
        /// <returns>cart satisfy conditions</returns>
        internal Cart GetCart(int cartId, string status, bool withItem)
        {
            List<Cart> carts = ReadCartText();
            Cart cart = new Cart();
            foreach (Cart carta in carts)
            {
                if (carta.CartID == cartId)
                {
                    Cart returnCart = ReadCartItemText(carta);
                    return returnCart;
                }
            }
            cart.UserName = "NotExist";
            return cart;
        }

        /// <summary>
        /// get list of cart by user name
        /// should get list of cart by userId, but made some mistakes while write this part
        /// and no time to fix all these
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="status"></param>
        /// <param name="withItem"></param>
        /// <returns></returns>
        internal List<Cart> GetCartUId(string userName, string status, bool withItem)
        {
            List<Cart> carts = ReadCartText();
            List<Cart> returnCarts = new List<Cart>();
            foreach (Cart item in carts)
            {
                if (item.UserName == userName)
                {
                    Cart cart = item;
                    if (withItem)
                    {
                        cart = ReadCartItemText(cart);
                    }
                    returnCarts.Add(cart);
                }
            }
            return returnCarts;
        }

        /// <summary>
        /// update cart information
        /// also use for insert cart into cart table
        /// </summary>
        /// <param name="cart">new cart</param>
        internal void CartUpdate(Cart cart)
        {
            /// update cart file
            List<Cart> readCarts = ReadCartText();
            List<string> writeCarts = new List<string>();
            string cartString = "";
            foreach (Cart item in readCarts)
            {
                if (cart.CartID == item.CartID)
                {
                    cartString = cart.CartID + "," + cart.UserName + "," + cart.Status + ",";
                }
                else
                {
                    cartString = item.CartID + "," + item.UserName + "," + item.Status + ",";
                }
                writeCarts.Add(cartString);
            }
            System.IO.File.WriteAllLines(path + @"Cart.txt", writeCarts);

            /// update cartItem file
            List<string[]> itemLines = ReadForWrite();
            List<string> writeItems = new List<string>();
            string cartItemString = "";
            foreach (string[] item in itemLines)
            {
                if (cart.CartID == Convert.ToInt32(item[0]))
                {
                    foreach (CartItem cartItem in cart.Items)
                    {
                        if (cartItem.ProductID == Convert.ToInt32(item[2]))
                        {
                            cartItemString = item[0] + "," + cartItem.Amount + "," + item[2];
                        }
                        else
                        {
                            cartItemString = item[0] + "," + item[1] + "," + item[2];
                        }
                        writeItems.Add(cartItemString);
                    }
                }
                else
                {
                    cartItemString = item[0] + "," + item[1] + "," + item[2];
                    writeItems.Add(cartItemString);
                }
            }
            System.IO.File.WriteAllLines(path + @"CartItem.txt", writeItems);

        }

        private List<string[]> ReadForWrite()
        {
            string[] lines = System.IO.File.ReadAllLines(path + @"DAL/CartItem.txt");
            List<string[]> returnLine = new List<string[]>();
            foreach (string line in lines)
            {
                string[] cartItemsInfo = line.Split(',');
                returnLine.Add(cartItemsInfo);
            }
            return returnLine;
        }
    }
}