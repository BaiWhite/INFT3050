﻿using INFT3050.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace INFT3050.DAL
{
    /// <summary>
    /// functions to deal with postage table
    /// </summary>
    public class PostageDataAccess
    {
        /// <summary>
        /// the path of the application
        /// </summary>
        String path = AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>
        /// read info in postage.txt
        /// </summary>
        /// <returns>lines</returns>
        private List<Postage> ReadPostageText()
        {
            string[] lines = System.IO.File.ReadAllLines(path + "DAL/Postage.txt");
            List<Postage> postages = new List<Postage>();
            Postage postage = new Postage();
            foreach (string line in lines)
            {
                string[] postageInfo = line.Split(',');
                postage.UserID = Convert.ToInt32(postageInfo[0]);
                postage.PostageID = Convert.ToInt32(postageInfo[1]);
                postage.ContactName = postageInfo[2];
                postage.Street = postageInfo[3];
                postage.City = postageInfo[4];
                postage.State = postageInfo[5];
                postage.Country = postageInfo[6];
                postage.ZipCode = postageInfo[7];
                postage.Phone = postageInfo[8];
            }
            return postages;
        }

        /// <summary>
        /// get list of postages of user based on userId
        /// </summary>
        /// <returns></returns>
        public List<Postage> GetPostages(string userId)
        {
            List<Postage> postages = ReadPostageText();
            List<Postage> returnPostages = new List<Postage>();
            foreach (Postage item in postages)
            {
                if (item.UserID == Convert.ToInt32(userId))
                {
                    returnPostages.Add(item);
                }
            }
            return postages;
        }

        /// <summary>
        /// update user postages, also use for insert a new postages
        /// </summary>
        /// <param name="newUser"></param>
        internal void Update(Postage postage)
        {
            List<Postage> postages = ReadPostageText();
            string update = "";

            List<string> postageUpdate = new List<string>();
            foreach (Postage postagea in postages)
            {
                if (postagea.UserID == postage.UserID && postage.PostageID == postagea.PostageID)
                {
                    update = postage.UserID + "," + postage.PostageID + "," + postage.ContactName + "," + postage.Street + "," + postage.City + "," + postage.State + "," + postage.Country + "," + postage.ZipCode + "," + postage.Phone;
                }
                else
                {
                    update = postagea.UserID + "," + postagea.PostageID + "," + postagea.ContactName + "," + postagea.Street + "," + postagea.City + "," + postagea.State + "," + postagea.Country + "," + postagea.ZipCode + "," + postagea.Phone;
                }
                postageUpdate.Add(update);
            }
            System.IO.File.WriteAllLines(path + @"Cart.txt", postageUpdate);
        }
    }
}