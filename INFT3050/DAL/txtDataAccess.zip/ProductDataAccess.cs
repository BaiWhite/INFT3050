﻿using INFT3050.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace INFT3050.DAL
{
    /// using product data base
    public class ProductDataAccess
    {
        /// <summary>
        /// the path of the application
        /// </summary>
        String path = AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>
        /// read info in Product.txt
        /// </summary>
        /// <returns>lines</returns>
        public List<Product> ReadProductText()
        {
            string[] lines = System.IO.File.ReadAllLines(path + "DAL/Product.txt");
            List<Product> products = new List<Product>();
            Product product = new Product();
            foreach (string line in lines)
            {
                string[] cartInfo = line.Split(',');
                product.ProductId = Convert.ToInt32(cartInfo[0]);
                product.Name = cartInfo[1];
                product.Price = cartInfo[2];
                product.Description = cartInfo[3];
                product.Status = cartInfo[4];
            }
            return products;
        }

        /// <summary>
        /// search for a list of product by key ward "search"
        /// </summary>
        /// <param name="search">keyward</param>
        /// <returns>products satisfy conditions</returns>
        public List<Product> SearchProduct(string search)
        {
            List<Product> products = ReadProductText();
            List<Product> returnProductss = new List<Product>();
            foreach (Product item in products)
            {
                if (item.Name.Contains(search))
                {
                    Product product = item;
                    returnProductss.Add(product);
                }
                else if (item.Description.Contains(search))
                {
                    Product product = item;
                    returnProductss.Add(product);
                }
            }
            return returnProductss;
        }

        /// <summary>
        /// update product information
        /// also use for insert product into cart table
        /// </summary>
        /// <param name="newProduct">new product info</param>
        internal void UpdateProduct(Product newProduct)
        {
            /// update cart file
            List<Product> readProducts = ReadProductText();
            List<string> writeProducts = new List<string>();
            string productString = "";
            foreach (Product item in readProducts)
            {
                if (newProduct.ProductId == item.ProductId)
                {
                    productString = newProduct.ProductId + "," + newProduct.Name + "," + newProduct.Price + "," + newProduct.Description + "," + newProduct.Status + ",";
                }
                else
                {
                    productString = item.ProductId + "," + item.Name + "," + item.Price + "," + item.Description + "," + item.Status + ",";
                }
                writeProducts.Add(productString);
            }
            System.IO.File.WriteAllLines(path + @"Cart.txt", writeProducts);
        }

        /// <summary>
        /// get the product information from data base by productId</summary>
        /// <param name="productId">product Id</param>
        /// <returns>product satisfy conditions</returns>
        public Product GetProduct(string productId)
        {
            List<Product> products = ReadProductText();
            Product product = new Product();
            foreach (Product producta in products)
            {
                if (producta.ProductId.ToString() == productId)
                {
                    return producta;
                }
            }
            product.Name = "NotExist";
            return product;
        }
    }
}