﻿using INFT3050.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace INFT3050.DAL
{
    /// <summary>
    /// Functions about UserTable
    /// </summary>
    public class UserDataAccess
    {
        /// <summary>
        /// the path of the application
        /// </summary>
        String path = AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>
        /// read info in User.txt
        /// </summary>
        /// <returns>lines</returns>
        public List<UserClass> ReadUserText()
        {
            string[] lines = System.IO.File.ReadAllLines(path + "DAL/User.txt");
            List<UserClass> users = new List<UserClass>();
            UserClass user = new UserClass();
            foreach (string line in lines)
            {
                string[] cartInfo = line.Split(',');
                user.UserID = Convert.ToInt32(cartInfo[0]);
                user.UserName = cartInfo[1];
                user.Email = cartInfo[2];
                user.Password = cartInfo[3];
                user.Role = cartInfo[4];
            }
            return users;
        }

        /// <summary>
        /// Check Login information with information in UserTable
        /// </summary>
        /// <param name="login"></param>
        /// <returns>userID if valid, otherwise "Invalid username or password"</returns>
        public string LoginDataBase(Login login)
        {
            List<UserClass> users = ReadUserText();
            UserClass user = new UserClass();
            foreach (UserClass usera in users)
            {
                if (usera.UserName == login.UserName)
                {
                    if (usera.Password == login.Password)
                    {
                        return usera.UserID.ToString();
                    }
                }
            }
            return "Invalid username or password";
        }

        /// <summary>
        /// Find user with userId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Return all user with List<UserClass> if userId="ALLUSER", otherwise only user with imput userid</returns>
        internal List<UserClass> FindUser(string userId)
        {
            List<UserClass> users = ReadUserText();
            UserClass user = new UserClass();
            if (userId == "ALLUSER")
            {
                return users;
            }

            List<UserClass> returnUsers = ReadUserText();
            foreach (UserClass usera in users)
            {
                if (usera.UserID.ToString() == userId)
                {
                    returnUsers.Add(usera);
                    return returnUsers;
                }
            }
            user.UserName = "NotExist";
            return users;
        }

        /// <summary>
        /// Register user
        /// </summary>
        /// <param name="registration"></param>
        /// <returns>if user name been used, return "User Name is Already Exist", otherwise "Registered"</returns>
        public string RegisterDataBase(UserClass registration)
        {
            List<UserClass> users = ReadUserText();
            UserClass user = new UserClass();
            string regist = "";
            foreach (UserClass usera in users)
            {
                if (usera.UserName == registration.UserName)
                {
                    return "User Name is Already Exist";
                }
            }

            int id = users[users.Count - 1].UserID + 1;
            if (registration.Role == "Admin")
            {
                regist = id + "," + registration.UserName + "," + registration.Email + "," + registration.Password + "," + registration.Role;
            }
            else
            {
                regist = id + "," + registration.UserName + "," + registration.Email + "," + registration.Password + ",User";
            }
            return "Registered";
        }

        /// <summary>
        /// update user information, also use for insert a new user by admin
        /// </summary>
        /// <param name="newUser"></param>
        internal void Update(UserClass newUser)
        {
            List<UserClass> users = ReadUserText();
            UserClass user = new UserClass();
            string update = "";

            List<string> userUpdate = new List<string>();
            foreach (UserClass usera in users)
            {
                if (usera.UserID == newUser.UserID)
                {
                    update = newUser.UserID + "," + newUser.UserName + "," + newUser.Email + "," + newUser.Password + "," + newUser.Role;
                }
                else
                {
                    update = usera.UserID + "," + usera.UserName + "," + usera.Email + "," + usera.Password + "," + usera.Role;
                }
                userUpdate.Add(update);
            }
            System.IO.File.WriteAllLines(path + @"Cart.txt", userUpdate);
        }
    }
}